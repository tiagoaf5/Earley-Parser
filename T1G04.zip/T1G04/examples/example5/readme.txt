Utilizacao de
* para indicar 0 ou mais
+ para indicar 1 ou mais
? para indicar 0 ou 1