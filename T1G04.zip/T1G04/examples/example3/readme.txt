Duas gramaticas para a mesma linguagem
Uma com recursividade a esquerda e outra sem utilizando terminais nulos
Bem sucedido em ambos os casos